const navBar = document.querySelector("nav"),
    menuBtns = document.querySelectorAll(".menu-icon"),
    overlay = document.querySelector(".overlay"),
    navLinks = document.querySelectorAll(".nav-link");

menuBtns.forEach((menuBtn) => {
    menuBtn.addEventListener("click", () => {
        navBar.classList.toggle("open");
    });
});

overlay.addEventListener("click", () => {
    navBar.classList.remove("open");
});

navLinks.forEach((link) => {
    link.addEventListener("click", () => {
        navLinks.forEach((otherLink) => otherLink.classList.remove("active"));
        link.classList.add("active");
    });
});
