from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request,'index.html',{})
def home(request):
    return render(request,'home.html',{})
def docs(request):
    return render(request,'docs.html',{})
def Image(request):
    return render(request,'Image.html',{})
def Text(request):
    return render(request, 'Text.html',{})
def Presentation(request):
    return render(request, 'Presentation.html',{})
def Spreadsheet(request):
    return render(request, 'Spreadsheet.html',{})
def Audio(request):
    return render(request,'Audio.html',{})
def Video(request):
    return render(request,'Video.html',{})
def Summarizer(request):
    return render(request,'Summarizer.html',{})
def QuestionAnswering(request):
    return render(request,'Qa.html',{})

def login(request):
    return render(request,'login.html',{})

from django.shortcuts import render
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM, pipeline

def translate(request):
    if request.method == 'POST':
        input_text = request.POST.get('input_text')
        input_language = request.POST.get('input_language')
        output_language = request.POST.get('output_language')

        model = AutoModelForSeq2SeqLM.from_pretrained("facebook/nllb-200-distilled-600M")
        tokenizer = AutoTokenizer.from_pretrained("facebook/nllb-200-distilled-600M")
        translator = pipeline('translation', model=model, tokenizer=tokenizer, src_lang=input_language, tgt_lang=output_language, max_length = 400)
        translated_text = translator(input_text)[0]['translation_text']

        context = {'input_text': input_text, 'translated_text': translated_text}
        return render(request, 'translate.html', context)

    return render(request, 'translate.html')