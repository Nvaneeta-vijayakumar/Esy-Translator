<script>
  document.getElementById("submitButton").addEventListener("click", function() {
    var email = document.getElementById("useremail").value;
    var password = document.getElementById("password").value;

    if (email.trim() === "acd" && password.trim() === "1234") {
      document.getElementById("signInForm").submit();
    } else {
      alert("Incorrect username or password");
    }
  });
</script>